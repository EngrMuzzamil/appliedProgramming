var crud = require('./crud')
const yarg = require('yargs');
yarg.command({
    command: 'add',
    builder: {
        title: {
            describe: 'Note title',
            demandOption: true,
            type: 'string'
        },
        body: {
            describe: 'Note body',
            demandOption: true,
            type: 'string'
        }
    },
    handler: function(argv) {
        crud.create(argv.title,argv.body);
    }
}).argv

yarg.command({
    command: 'read',
    handler: function() {
        crud.read();
    }
}).argv

yarg.command({
    command: 'update',
    builder: {
        title: {
            describe: 'Note title',
            demandOption: true,
            type: 'string'
        },
        body: {
            describe: 'Note body',
            demandOption: true,
            type: 'string'
        }
    },
    handler: function(argv) {
        crud.update(argv.title,argv.body);
    }
}).argv

yarg.command({
    command: 'delete',
    handler: function() {
        crud.delete();
    }
}).argv
